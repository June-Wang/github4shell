Utility Library
===============

Functions abstracted from top level scripts.

There are more functions and aliases with interactive focus in the [.bash.d/](https://github.com/HariSekhon/DevOps-Bash-tools/tree/master/.bash.d) directory at the top level.
